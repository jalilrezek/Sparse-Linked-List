package hw2;

import exceptions.IndexException;
import exceptions.LengthException;
import java.util.Iterator;
import java.util.NoSuchElementException;


/**
 * An implementation of an IndexedList designed for cases where
 * only a few positions have distinct values from the initial value.
 *
 * @param <T> Element type.
 */
public class SparseIndexedList<T> implements IndexedList<T> {

  private Node<T> head; // should be initialized to Null cuz no value given. But if it later acquires a "next" Node, but has no data value of type T, what will become of it? What datatype should Head be? need I make a separate datatype for it that just stores the next Node?
  private int length;
  private T defaultVal;


  /**
   * Constructs a new SparseIndexedList of length size
   * with default value of defaultValue.
   *
   * @param size Length of list, expected: size > 0.
   * @param defaultValue Default value to store in each slot.
   * @throws LengthException if size <= 0.
   */
  public SparseIndexedList(int size, T defaultValue) throws LengthException {
    // TODO - upon construction, get() ensures that any valid index will return default, cuz no Nodes added yet
    if (size <= 0) {
      throw new LengthException();
    }
    length = size;
    head = null; // at first, head is null and it's only default values that we have. Is it right to initialize to null?
    defaultVal = defaultValue;


  }

  @Override
  public int length() {
    // TODO - should be done.
    return length; // was initially 0
  }



  private boolean isValid(int index) {
    return index >= 0 && index < length();
  } //mine

  @Override
  public T get(int index) throws IndexException {
    // TODO
    if(!isValid(index)) {
      throw new IndexException();
    }

    Node<T> node = head; // is this the right way to "make" a Node for purposes of this function? I.e. if list is empty, don't want to actually have this make a new node cuz there should be none.
    while (node != null) {
      if (node.index == index) {
        return node.data;
      }
      node = node.next;
    }
    // if we've exited the while loop, there was no matching node. Must return defaultVal
    return defaultVal;
    //return null;
  }

  @Override
  public void put(int index, T value) throws IndexException {
    // TODO
    // there are two main parts to this method. Putting nodes in in the right order - that is, after
    // put() finishes, nodes should always be connected in ascending order with respect to their
    // indices - and secondly, removal. Removal shouldn't be too hard if nodes are already in order.

    // 2/14 7pm: What this program should do is initially add a node at the given index,
    // even if it has default val, and then if it has default val, delete it and reconnect
    // remaining nodes accordingly

    if(!isValid(index)) {
      throw new IndexException();
    }

    Node<T> n = new Node<T>();
    n.data = value;
    n.index = index;
    if (head == null && value == defaultVal) { // if this is true, the list is empty, and we're just adding another defaulVal (i.e. nothing)
      return;
    } else if (head == null) {
      head = n;
      return;
    } else {
      n.next = head; // initialize the new Node into position before Head.
      //numNodes++; // there's a new Node - numNodes must be incremented, at least initially. This will be undone if it turns out to be a default valued Node which is erased.
    }

    Node<T> current = head;
    int counter = 0;

    while (current != null) {
      if (n.index == current.index) { // i.e. we are simply replacing the Node at current index.
        current.data = n.data; // this should override current with n. The index stays the same, and the next Node is the same.
        break;
      } else if (n.index > current.index && current.next == null) { // append n to the end of the list
        current.next = n;
        n.next = null; // otherwise it would still point to head, making a circular list
        break;
      } else if (n.index > current.index && n.index < current.next.index) { // n belongs in between current and the one after current
        n.next = current.next;
        current.next = n; // situate n in between current and current.next
        break;
      } else if (n.index < current.index && counter == 0) { // n comes before head
        break; // n is initialized pointing to head
      } else { // we need to keep going over the list.
        current = current.next;
        counter++;
      }
    }

    // If we delete a Node at the beginning, all is well.
    // If we delete a Node at the end, all is well.

    // Now we have to make sure that, if we deleted a Node in the middle, we connect the one
    // that was before it to the one that was after it.

    Node<T> curr2 = head;

    if (value == defaultVal && counter != 0) { // delete a Node besides the very first one (Head)
      //numNodes--;
      for (int i = 0; i < counter - 1; i++) { // I think stopping at counter - 1 is correct, cuz we call upon curr2.next
        curr2 = curr2.next; // this should stop at the node before the one with defaultVal which we just added
      }
      curr2.next = curr2.next.next; // connect the node before the one with defaultVal just added, to the next next node
      curr2.next = null; // delete the node with defaultVal we just added. Is this line even necessary? Will garbage collector destroy it?
    } else if (value == defaultVal && counter == 0) { // deleting the Head
      head = head.next; // now nothing points to Head right? So it should get collected and destroyed.
      //numNodes--;
    }

  }

  @Override
  public Iterator<T> iterator() {
    return new SparseIndexedListIterator();
  }

  private static class Node<T> {
    T data;
    Node<T> next;
    int index;
  }

  private class SparseIndexedListIterator implements Iterator<T> { // if only non-default indices have Nodes, then how will this present all indices?

    private Node<T> current;
    private int cursor;

    SparseIndexedListIterator() { // the nodes should all be ordered by index already, thanks to put()
      current = head;
      cursor = 0;
    }
    @Override
    public boolean hasNext() {
      // TODO
      return cursor < length; //MINE we want to go all the way to length-1 even if it's just default
      // returning current != null would mean if we start with an empty list, it doesn't iterate at all - it means any time we come across a null, it just discontinues the loop.
    }

    @Override
    public T next() throws NoSuchElementException {
      // TODO
      if (!hasNext()) { //mine
        throw new NoSuchElementException();
      }


      if ( (current != null) && (cursor == current.index) ) { // if you don't check that current isn't null, it will crash because cannot access index of Null
        cursor++;
        T t = current.data;
        current = current.next;
        return t;
      } else {
        cursor++;
        return defaultVal;
      }


     // return null;
    }
  }
}
